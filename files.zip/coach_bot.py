#!/usr/bin/env python3
"""
Virtual Coaching Bot — City2Surf Edition
- Daily 6am AEST training briefing via Telegram
- Post-workout analysis after each Intervals.icu upload
"""

import os
import json
import time
import base64
import logging
import requests
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from dotenv import load_dotenv
import anthropic

# Load .env from same directory as this script
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(os.path.join(os.path.dirname(__file__), "coach_bot.log")),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
TELEGRAM_TOKEN        = os.environ["TELEGRAM_BOT_TOKEN"]
TELEGRAM_CHAT_ID      = os.environ["TELEGRAM_CHAT_ID"]
ANTHROPIC_API_KEY     = os.environ["ANTHROPIC_API_KEY"]
INTERVALS_API_KEY     = os.environ["INTERVALS_API_KEY"]
INTERVALS_ATHLETE_ID  = os.environ["INTERVALS_ATHLETE_ID"]

AEST       = ZoneInfo("Australia/Sydney")
STATE_FILE = os.path.join(os.path.dirname(__file__), "state.json")

# ── Athlete context (used in every Claude prompt) ─────────────────────────────
ATHLETE_CONTEXT = """
Athlete profile:
- Goal race: City2Surf Sydney, August 2026 (14km road race, iconic course from Hyde Park to Bondi Beach)
- Key challenge: Heartbreak Hill at ~10km — a steep 1.8km climb that breaks most runners
- Training for: strong finish time, negative split strategy, surviving the hill with energy to sprint Bondi
- Location: Sydney, Australia
- Training platform: Intervals.icu with structured plan already loaded
"""

# ── Telegram ──────────────────────────────────────────────────────────────────
def send_telegram(message: str) -> bool:
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "Markdown"}
    try:
        r = requests.post(url, json=payload, timeout=15)
        r.raise_for_status()
        log.info("Telegram sent ✓")
        return True
    except Exception as e:
        log.error(f"Telegram failed: {e}")
        return False

# ── State ─────────────────────────────────────────────────────────────────────
def load_state() -> dict:
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"last_activity_id": None, "last_briefing_date": None}

def save_state(state: dict):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

# ── Intervals.icu API ─────────────────────────────────────────────────────────
def _auth_header() -> dict:
    token = base64.b64encode(f"API_KEY:{INTERVALS_API_KEY}".encode()).decode()
    return {"Authorization": f"Basic {token}"}

def intervals_get(path: str):
    try:
        r = requests.get(
            f"https://intervals.icu/api/v1{path}",
            headers=_auth_header(),
            timeout=15,
        )
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.error(f"Intervals API error ({path}): {e}")
        return None

def get_todays_event() -> dict | None:
    today = datetime.now(AEST).strftime("%Y-%m-%d")
    data = intervals_get(
        f"/athlete/{INTERVALS_ATHLETE_ID}/events?oldest={today}&newest={today}"
    )
    if isinstance(data, list):
        for ev in data:
            if ev.get("category") not in ("NOTE", "RACE"):
                return ev
    return None

def get_wellness() -> dict | None:
    today     = datetime.now(AEST).strftime("%Y-%m-%d")
    yesterday = (datetime.now(AEST) - timedelta(days=1)).strftime("%Y-%m-%d")
    data = intervals_get(
        f"/athlete/{INTERVALS_ATHLETE_ID}/wellness?oldest={yesterday}&newest={today}"
    )
    if isinstance(data, list):
        for record in reversed(data):
            if record:
                return record
    return None

def get_recent_activities(n: int = 5) -> list:
    today    = datetime.now(AEST).strftime("%Y-%m-%d")
    week_ago = (datetime.now(AEST) - timedelta(days=7)).strftime("%Y-%m-%d")
    data = intervals_get(
        f"/athlete/{INTERVALS_ATHLETE_ID}/activities?oldest={week_ago}&newest={today}"
    )
    if isinstance(data, list):
        return sorted(data, key=lambda x: x.get("start_date_local", ""), reverse=True)[:n]
    return []

def get_activity_detail(activity_id: str) -> dict | None:
    return intervals_get(f"/athlete/{INTERVALS_ATHLETE_ID}/activities/{activity_id}")

def get_latest_activity() -> dict | None:
    acts = get_recent_activities(1)
    return acts[0] if acts else None

# ── Claude helpers ─────────────────────────────────────────────────────────────
def ask_claude(system: str, user: str) -> str:
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    try:
        msg = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        return msg.content[0].text
    except Exception as e:
        log.error(f"Claude API error: {e}")
        return "⚠️ Coach is unavailable right now — check back shortly."

# ── Daily Briefing ─────────────────────────────────────────────────────────────
def generate_briefing() -> str:
    today_str = datetime.now(AEST).strftime("%A, %d %B %Y")
    event     = get_todays_event()
    wellness  = get_wellness()
    recent    = get_recent_activities(3)

    # Weeks until City2Surf (first Sunday of August 2026)
    race_date = datetime(2026, 8, 9, tzinfo=AEST)
    days_out  = (race_date - datetime.now(AEST)).days
    weeks_out = days_out // 7

    ctx = [f"Date: {today_str}", f"Weeks to City2Surf: {weeks_out} ({days_out} days)"]

    if wellness:
        hrv = wellness.get("hrv")
        rhr = wellness.get("restingHR")
        ctl = wellness.get("ctl")
        atl = wellness.get("atl")
        tsb = wellness.get("tsb")
        ctx.append(
            f"\nWellness: HRV {hrv or 'N/A'} ms | RHR {rhr or 'N/A'} bpm"
            f"\nForm scores: Fitness (CTL) {round(ctl,1) if ctl else 'N/A'} | "
            f"Fatigue (ATL) {round(atl,1) if atl else 'N/A'} | "
            f"Form (TSB) {round(tsb,1) if tsb else 'N/A'}"
        )

    if event:
        name  = event.get("name", "Run")
        desc  = event.get("description", "No description")
        dur_s = event.get("moving_time")
        dist  = event.get("distance")
        dur_str  = f"{dur_s//60} min" if dur_s else ""
        dist_str = f"{round(dist/1000,1)} km" if dist else ""
        ctx.append(f"\nToday's plan: {name} {dist_str} {dur_str}\n{desc}")
    else:
        ctx.append("\nNo session scheduled — rest or easy recovery day.")

    if recent:
        ctx.append("\nRecent sessions:")
        for a in recent:
            d    = a.get("start_date_local","")[:10]
            nm   = a.get("name","Run")
            km   = f"{round(a.get('distance',0)/1000,1)} km" if a.get("distance") else ""
            mins = f"{a.get('moving_time',0)//60} min" if a.get("moving_time") else ""
            load = a.get("training_load")
            ctx.append(f"  • {d}: {nm} {km} {mins}" + (f" | Load {round(load)}" if load else ""))

    context_block = "\n".join(ctx)

    system = (
        "You are an expert running coach specialising in road racing and Sydney events. "
        "You deliver sharp, motivating, data-driven daily briefings. "
        "Tone: direct, encouraging, like a trusted coach who knows the athlete well. "
        "Format for Telegram: use *bold* for headings, emoji sparingly. Length: 220-280 words."
    )
    user = (
        f"{ATHLETE_CONTEXT}\n\nData for today:\n{context_block}\n\n"
        "Write the daily briefing. Cover:\n"
        "1. *Readiness* — what the wellness numbers say (use plain English, not just numbers)\n"
        "2. *Today's session* — what to do, how to pace it, what to focus on\n"
        "3. *City2Surf context* — brief mention of how today fits the race prep (Heartbreak Hill, "
        "pacing strategy, or countdown milestone if notable)\n"
        "4. One-line motivational sign-off. Do NOT use generic filler."
    )
    return ask_claude(system, user)

# ── Post-Workout Analysis ──────────────────────────────────────────────────────
def generate_analysis(activity: dict, planned: dict | None) -> str:
    name      = activity.get("name", "Run")
    wtype     = activity.get("type", "Run")
    date      = activity.get("start_date_local", "")[:10]
    dist_km   = round(activity.get("distance", 0) / 1000, 2)
    dur_min   = activity.get("moving_time", 0) // 60
    load      = activity.get("training_load")
    hr_avg    = activity.get("average_heartrate")
    hr_max    = activity.get("max_heartrate")
    pace_ms   = activity.get("average_speed")       # m/s
    ctl       = activity.get("ctl")
    atl       = activity.get("atl")
    tsb       = activity.get("tsb")
    suffer    = activity.get("suffer_score")
    elevation = activity.get("total_elevation_gain")

    pace_str = "N/A"
    if pace_ms and pace_ms > 0:
        pm = 1000 / pace_ms / 60
        pace_str = f"{int(pm)}:{int((pm % 1)*60):02d} /km"

    actual = (
        f"Activity: {name} ({wtype}) — {date}\n"
        f"Distance: {dist_km} km | Duration: {dur_min} min | Pace: {pace_str}\n"
        f"Avg HR: {hr_avg or 'N/A'} bpm | Max HR: {hr_max or 'N/A'} bpm"
    )
    if elevation:
        actual += f" | Elevation: {round(elevation)} m"
    if load:
        actual += f"\nTraining load: {round(load)}"
    if suffer:
        actual += f" | Suffer score: {suffer}"
    if ctl:
        actual += (
            f"\nPost-run form: Fitness {round(ctl,1)} | "
            f"Fatigue {round(atl,1) if atl else 'N/A'} | "
            f"Form {round(tsb,1) if tsb else 'N/A'}"
        )

    plan_ctx = "No specific session was planned today."
    if planned:
        plan_ctx = (
            f"Planned: {planned.get('name','')} — "
            f"{planned.get('description','(no description)')}"
        )

    system = (
        "You are an expert running coach specialising in City2Surf preparation. "
        "Deliver post-run feedback that's specific, data-driven, and actionable. "
        "Format for Telegram: *bold* headings, emoji sparingly. Length: 260-320 words."
    )
    user = (
        f"{ATHLETE_CONTEXT}\n\nActual run:\n{actual}\n\nPlan:\n{plan_ctx}\n\n"
        "Write the post-workout analysis. Cover:\n"
        "1. *Execution* — how well did actual match the plan? What the numbers show.\n"
        "2. *Physiological read* — what HR, pace, and load tell us about effort and fitness.\n"
        "3. *City2Surf relevance* — did this session build anything specific for race day "
        "(hill strength, threshold, aerobic base, fatigue management)?\n"
        "4. *Next session tip* — one concrete, specific thing to focus on next time.\n"
        "Be honest — if it was too easy, too hard, or off-plan, say so constructively."
    )
    return ask_claude(system, user)

# ── Main loop ──────────────────────────────────────────────────────────────────
def run():
    log.info("🏃 City2Surf coaching bot started")
    state = load_state()

    # On first run, record current latest activity so we don't re-analyse old ones
    if state.get("last_activity_id") is None:
        latest = get_latest_activity()
        if latest:
            state["last_activity_id"] = str(latest.get("id"))
            save_state(state)
            log.info(f"Baseline activity set: {state['last_activity_id']}")

    while True:
        now = datetime.now(AEST)

        # ── Daily briefing at 06:00 AEST ──────────────────────────────────────
        today_str = now.strftime("%Y-%m-%d")
        if now.hour == 6 and now.minute < 5 and state.get("last_briefing_date") != today_str:
            log.info("Generating daily briefing…")
            try:
                briefing = generate_briefing()
                header   = f"🌅 *Good morning! Daily Training Briefing*\n_{now.strftime('%A, %d %B')}_\n\n"
                send_telegram(header + briefing)
                state["last_briefing_date"] = today_str
                save_state(state)
            except Exception as e:
                log.error(f"Briefing error: {e}")

        # ── Post-workout analysis — poll for new activities ────────────────────
        try:
            latest = get_latest_activity()
            if latest:
                act_id = str(latest.get("id"))
                if act_id != state.get("last_activity_id"):
                    log.info(f"New activity detected: {act_id}")
                    time.sleep(90)  # wait for Intervals to finish processing
                    activity = get_activity_detail(act_id) or latest
                    planned  = get_todays_event()
                    analysis = generate_analysis(activity, planned)
                    header   = "💪 *Post-Run Analysis*\n\n"
                    send_telegram(header + analysis)
                    state["last_activity_id"] = act_id
                    save_state(state)
        except Exception as e:
            log.error(f"Activity check error: {e}")

        time.sleep(300)  # poll every 5 minutes

if __name__ == "__main__":
    run()
